// background.js - Minimal content for testing service worker registration
console.log("Feldman-ifier background service worker loaded.");

chrome.runtime.onInstalled.addListener(() => {
    console.log("Feldman-ifier installed.");
});
// Global variable to store the auto-swap state
let autoSwapEnabled = false;
const NUM_FELDMAN_IMAGES = 62; // Update this if your image count changes!

// Function to replace all images on the page
function replaceAllImages() {
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        // Generate a random number between 1 and NUM_FELDMAN_IMAGES
        const randomIndex = Math.floor(Math.random() * NUM_FELDMAN_IMAGES) + 1;
        const feldmanImageUrl = chrome.runtime.getURL(`images/feldman${randomIndex}.jpg`); // Assuming .jpg

        // Only replace if it's not already a Feldman image to prevent infinite loop or unnecessary re-swaps
        if (!img.src.includes("images/feldman")) {
             // To handle potential lazy loading, store original src and replace
            const originalSrc = img.src;
            img.dataset.originalSrc = originalSrc; // Store original src in a data attribute
            img.src = feldmanImageUrl;
            img.srcset = ''; // Clear srcset to ensure our src is used
            img.alt = 'Corey Feldman'; // Update alt text for accessibility
        }
    });
}

// Function to observe for new images added to the DOM
let observer;
function setupMutationObserver() {
    if (observer) {
        observer.disconnect(); // Disconnect existing observer if any
    }

    if (autoSwapEnabled) {
        observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.addedNodes) {
                    mutation.addedNodes.forEach((node) => {
                        if (node.nodeType === 1 && node.tagName === 'IMG') { // Check if it's an image
                            // Replace the newly added image
                            const randomIndex = Math.floor(Math.random() * NUM_FELDMAN_IMAGES) + 1;
                            const feldmanImageUrl = chrome.runtime.getURL(`images/feldman${randomIndex}.jpg`);
                            node.src = feldmanImageUrl;
                            node.srcset = '';
                            node.alt = 'Corey Feldman';
                        } else if (node.nodeType === 1) { // Also check for images within added elements
                            const newImages = node.querySelectorAll('img');
                            newImages.forEach(img => {
                                // Only replace if it's not already a Feldman image
                                if (!img.src.includes("images/feldman")) {
                                    const randomIndex = Math.floor(Math.random() * NUM_FELDMAN_IMAGES) + 1;
                                    const feldmanImageUrl = chrome.runtime.getURL(`images/feldman${randomIndex}.jpg`);
                                    img.src = feldmanImageUrl;
                                    img.srcset = '';
                                    img.alt = 'Corey Feldman';
                                }
                            });
                        }
                    });
                }
            });
        });

        // Start observing the entire document body for changes
        observer.observe(document.body, { childList: true, subtree: true });
    }
}

// --- NEW CENTRALIZED MESSAGE HANDLER FOR content.js ---
// This function will be called by both chrome.runtime.onMessage and chrome.scripting.executeScript
function handleMessageFromPopup(request) {
    if (request.action === 'swapImages') {
        replaceAllImages();
    } else if (request.action === 'toggleAutoSwap') {
        autoSwapEnabled = request.enabled;
        if (autoSwapEnabled) {
            replaceAllImages(); // Do an initial swap on toggle
            setupMutationObserver(); // Start observing for new images
        } else {
            if (observer) {
                observer.disconnect(); // Stop observing
            }
            // Optional: If you want to revert images when auto-swap is turned off
            // revertAllImages(); // You'd need to implement this function
        }
    }
    // No explicit 'initialLoadCheck' needed here anymore as initial load is handled by storage.sync.get
}

// Expose the handler globally so chrome.scripting.executeScript can call it
window.handleMessageFromPopup = handleMessageFromPopup;


// Listen for messages from popup.js or background.js (still keep this for reliability)
chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    handleMessageFromPopup(request);
    // Returning true indicates that sendResponse will be called asynchronously
    // However, since we're not actually sending a response back in this flow,
    // you could omit `return true;` if you prefer, but it doesn't hurt.
    // If you were expecting a response, it would be essential.
});

// Initial setup on page load: check storage for autoSwapEnabled state
chrome.storage.sync.get('autoSwapEnabled', (data) => {
    autoSwapEnabled = data.autoSwapEnabled || false;
    if (autoSwapEnabled) {
        replaceAllImages(); // Perform initial swap if auto-swap is enabled
        setupMutationObserver(); // Start observing for new images
    }
});
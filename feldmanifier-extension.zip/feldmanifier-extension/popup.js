document.addEventListener('DOMContentLoaded', () => {
    const swapImagesBtn = document.getElementById('swapImagesBtn');
    const autoSwapCheckbox = document.getElementById('autoSwapCheckbox');

    // Load saved preference for auto-swap
    chrome.storage.sync.get('autoSwapEnabled', (data) => {
        autoSwapCheckbox.checked = data.autoSwapEnabled || false;
    });

    // Event listener for the "Swap All Images Now" button
    swapImagesBtn.addEventListener('click', () => {
        chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
            if (tabs.length > 0) {
                chrome.tabs.sendMessage(tabs[0].id, { action: 'swapImages' });
            }
        });
    });

    // Event listener for the "Auto-Swap on Page Load" checkbox
    autoSwapCheckbox.addEventListener('change', () => {
        const autoSwapEnabled = autoSwapCheckbox.checked;
        chrome.storage.sync.set({ autoSwapEnabled: autoSwapEnabled }, () => {
            // Also inform the content script immediately if it's already active
            chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
                if (tabs.length > 0) {
                    chrome.tabs.sendMessage(tabs[0].id, {
                        action: 'toggleAutoSwap',
                        enabled: autoSwapEnabled
                    });
                }
            });
        });
    });
});